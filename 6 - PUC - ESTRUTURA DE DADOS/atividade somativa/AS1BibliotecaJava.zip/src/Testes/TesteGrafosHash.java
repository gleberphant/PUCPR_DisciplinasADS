package Testes;

import Infraestrutura.EstruturasDeDados.Grafos.GrafoHash;

public class TesteGrafosHash {
    public static void main(String[] args) {

        int itens[] = { 1, 2, 3, 4, 5, 6, 7 };

        GrafoHash<Integer> g = new GrafoHash<Integer>();

        System.out.println("\n Grafo do tipo: " + g.getClass());

        for (Integer item : itens)
            g.InserirItem(item);

        g.InserirConexao(1, 3);
        g.InserirConexao(1, 2);

        g.InserirConexao(2, 3);
        g.InserirConexao(2, 5);
        g.InserirConexao(2, 4);

        g.InserirConexao(7, 4);
        g.InserirConexao(7, 4);
        g.InserirConexao(7, 4);

        System.out.println(g.toString());
    }
}
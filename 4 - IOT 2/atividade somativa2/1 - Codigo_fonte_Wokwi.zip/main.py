
from machine import ADC, Pin
from umqtt.simple import MQTTClient
import network
import time
import dht
import json

class Comunicao:

    def __init__(self):
        print("INICIANDO MODULO COMUNICAÇÃO  ") 
        self.conectarWifi()
        self.conectarBroker()
        self.callback = {
            "topico":'', 
            "payload":''
        }        
              

    def conectarWifi(self, ssid="Wokwi-GUEST"):
        print("INICIANDO CONEXAO WIFI") 
        try:
            self.conexao = network.WLAN(network.STA_IF)
            self.conexao.active(True)
            self.conexao.connect(ssid,"")

            while not self.conexao.isconnected():
                print(".",end="")
                time.sleep(0.2)

        except Exception as e:
            print(f"Erro wifi.Conectar: {e} ")
            raise SystemExit("Exiting program due to an error")


        print("\n Conectado!")
        

    def conectarBroker(self):
        print("INICIANDO CONEXAO BROKER MQTT")        
        try:
            self.broker = MQTTClient (
                client_id="",
                user="device",
                password="1Q8AwstdiS8KU4Sp27_ZD0bbsjUgymqQ",
                server="blynk.cloud",
                port=1883,
                keepalive=45
            ) 
        
            self.broker.connect()

        except Exception as e:
            print(f"Erro broker.Conectar : {e} ")
            raise SystemExit("Exiting program due to an error")

        self.topicoEnvio = "batch_ds"
        self.topicoRecebimento = "downlink/ds"
        self.broker.set_callback(self.__callbackMensagem__)
        
        self.broker.subscribe(f"{self.topicoRecebimento}/#".encode())


    def __callbackMensagem__(self, topico, payload):
        try:
            print(f"Recebido: topico {topico} payload: {payload}")    
            
            self.callback = {
                "topico": topico.decode(),
                "payload": payload.decode() 
            }
            
        except Exception as e:
            print("Erro no broker.callbackMsg : ", e)
        


    def publicarMsg(self, payload=""):
        try:
            self.broker.publish(self.topicoEnvio.encode(), payload)
            print("Paylod Enviado: ", payload)
        except Exception as e:
            print("Erro no broker.publicarMsg : ", e)


    def verificarMensagens(self):
        self.callback = None

        try:
            self.broker.check_msg()     
        except Exception as e:
            print("Erro no broker.verificarMsg :", e)
            
        return self.callback


class UnidadeIrrigacao:
    def __init__(self):
        print("INICIANDO UNIDADE DE CONTROLE  ") 
        self.umidadeMaxima = 30

        self.umidade = 0
        self.consumo = 0
        self.modoManual = False
        self.nivelReservatorio = 100

        self.ultimaAtualizacao = time.time()

        self.__init_sensores__()
        self.__init_atuadores__()


    def __init_sensores__(self):
        print("INICIANDO SENSORES  ") 
        self.sensorUmidade = ADC(Pin(34))
        self.sensorUmidade.atten(ADC.ATTN_11DB)
        self.sensorReservatorio = ADC(Pin(35))
        self.sensorReservatorio.atten(ADC.ATTN_11DB)
        

    def __init_atuadores__(self):
        print("INICIANDO ATUADORES") 
        self.atuador = Pin(2, Pin.OUT)
        self.atuador.off()
        self.irrigadores = False
    

    def __deveIrrigar__(self):       
        return (
            self.nivelReservatorio > 10 and (
                (not self.modoManual and self.umidade < self.umidadeMaxima) or 
                (self.modoManual and self.irrigadores)
        )
        )

    def atualizarSensores(self):
        print("... REALIZANDO MEDIÇÃO  ") 
        try:
            self.umidade = round((self.sensorUmidade.read() / 4095) * 100)
            self.consumo += 1 if self.irrigadores == True else 0
            self.ultimaAtualizacao = time.time()
            self.nivelReservatorio = round((self.sensorReservatorio.read() / 4095) * 100)
        except Exception as e:
            print(f"Erro na leitura dos sensores {e}")


    def atualizarAtuadores(self, mensagem=None):
        print("... CONTROLANDO ATUADORES  ") 
        if mensagem is not None:
            try:
                if "modoManual" in mensagem["topico"] :
                    print(f"Modo Manual {mensagem['payload']}")
                    self.modoManual = bool(int(mensagem["payload"]) )
                    self.irrigadores = bool(int(mensagem["payload"]))

                if "umidadeMaxima" in mensagem["topico"] :
                    print(f"Nova umidade maxima {mensagem['payload']}")
                    self.umidadeMaxima = int(mensagem["payload"] )
            except Exception as e:
                print(f"Erro no tratamento de ordens manuais: {e}")

        try:
            if self.__deveIrrigar__():    
                self.atuador.on()
                self.irrigadores = True
            else:
                self.atuador.off()
                self.irrigadores = False

        except Exception as e:
            print(f"Erro no Controle dos atuadores : {e}")


    def payloadEnvio(self):

        return json.dumps({
            'umidade':self.umidade, 
            'modoManual': int(self.modoManual),
            'consumo': self.consumo,
            'irrigadores': int(self.irrigadores),
            'umidadeMaxima': self.umidadeMaxima,
            'nivelReservatorio': self.nivelReservatorio,
            'timestamp': self.ultimaAtualizacao
            })

def main():
    
    conexao = Comunicao()    

    unidade = UnidadeIrrigacao()

    print("INICIANDO LOOP")
    while True:

        print("_____________________ ")
      
        
        ordensManuais = conexao.verificarMensagens()

        unidade.atualizarSensores()     
        
        unidade.atualizarAtuadores(ordensManuais)          

        conexao.publicarMsg( unidade.payloadEnvio() )    
        

        print("_____________________ ")
        time.sleep(2)


        
main()
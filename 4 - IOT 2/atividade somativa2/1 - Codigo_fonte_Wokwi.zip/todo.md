TODO:




DONE
- refatorar para receber comandos do blink. blink envia comandor por topicos
- medidor de nivel de agua
- refatorar codigo
- receber comandos do broket MQTT
- interface grafica com blink


#define BLYNK_TEMPLATE_ID "TMPL2iGWIKllu"
#define BLYNK_TEMPLATE_NAME "ControleIrrigacao"
#define BLYNK_AUTH_TOKEN "1Q8AwstdiS8KU4Sp27_ZD0bbsjUgymqQ"